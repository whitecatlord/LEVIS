"""Convenience CLI; Base and execution policy remain in the frozen runner."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = 'Base_LEVIS_1_0_RECONCILED_FLOOR_R0_2_CANDIDATE.zip'


def verify():
    entries = {}
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        if name in entries or Path(name).is_absolute() or '..' in Path(name).parts:
            raise ValueError('invalid_manifest')
        entries[name] = digest
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts
              and p.relative_to(ROOT).as_posix() != 'MANIFEST_SHA256.txt'}
    if actual != set(entries):
        raise ValueError('package_member_set_changed')
    for name, digest in entries.items():
        p = ROOT / name
        if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            raise ValueError('package_hash_mismatch: ' + name)
    return len(entries)


def main():
    p = argparse.ArgumentParser(description='LEVIS bounded stock MVP, Linux/root only')
    p.add_argument('command', choices=['verify', 'plan', 'run', 'status'])
    p.add_argument('--input', type=Path)
    p.add_argument('--expect-input-sha256')
    p.add_argument('--retry')
    p.add_argument('--state', type=Path, default=Path('/root/levis-mvp-state'))
    a = p.parse_args()
    count = verify()
    if a.command == 'verify':
        print(json.dumps({'status': 'PASS', 'package_files': count,
                          'qualification': 'Byte integrity only; unsigned trusted bootstrap.'}))
        return 0
    cmd = [sys.executable, str(ROOT / 'task_runner.py'), '--state', str(a.state), a.command]
    if a.command != 'status':
        if not a.input:
            p.error('--input is required for plan/run')
        cmd += ['--archive', str(ROOT / BASE), '--input', str(a.input)]
        if a.expect_input_sha256:
            cmd += ['--expect-input-sha256', a.expect_input_sha256]
        if a.retry:
            cmd += ['--retry', a.retry]
    return subprocess.call(cmd)


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    try:
        sys.exit(main())
    except (ValueError, OSError) as exc:
        print(json.dumps({'status': 'REFUSED', 'reason': str(exc)}))
        sys.exit(2)
