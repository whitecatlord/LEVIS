"""Assertion controls for R1 review findings; real crashes use unchanged reviewer injector."""
import hashlib,importlib.util,json,os,subprocess,sys,tempfile,time,zipfile
from pathlib import Path
os.umask(0o077)
sys.dont_write_bytecode=True
work=Path(sys.argv[1]); archive=Path(sys.argv[2]); report_path=Path(sys.argv[3])
runner=work/'task_runner.py'; inject=work/'review_input/TOOLS/inject.py'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='51d1c276caac42b185eee22927c6cee2376bdd16a1b70df18e1b7bb6503f1aab'
pre=Path('/root/rv/pre/tree')
if pre.exists():
 with zipfile.ZipFile(archive) as z:
  for n in z.namelist():
   if not n.endswith('/'): assert (pre/n).read_bytes()==z.read(n)
else:
 pre.mkdir(parents=True,mode=0o700)
 with zipfile.ZipFile(archive) as z: z.extractall(pre)
base=Path(tempfile.mkdtemp(prefix='runner_repair_controls_',dir='/root'))
checks=[]
def call(state, fault='none', command='run', inp=None, arc=None, retry=None, extra=(), expected=0):
 args=[sys.executable,str(inject),fault,str(runner),'--state',str(state),command]
 if command!='status': args+=['--archive',str(arc or archive),'--input',str(inp or work/'example_stock.json'),*extra]
 if retry: args+=['--retry',retry]
 p=subprocess.run(args,capture_output=True,text=True,timeout=8)
 assert p.returncode==expected,(args,p.returncode,p.stdout,p.stderr)
 return json.loads(p.stdout) if p.stdout.strip() else None
s=base/'fork'
f=call(s,'exec_raises',expected=1); assert f['status']=='FAILED'; checks.append('execution_exception_exit1_saved')
call(s,'crash_after_child_prepared',retry=f['task_id'],expected=137)
st=call(s,command='status'); child=next(r for r in st['tasks'] if r['retry_of'])
r=call(s,retry=f['task_id'],expected=2); assert 'already_has_child' in r['reason']; checks.append('P1_orphan_child_blocks_parent_retry')
c=call(s,retry=child['task_id']); assert c['status']=='COMPLETED'
for prior in (f['task_id'],child['task_id']):
 r=call(s,retry=prior,expected=2); assert 'terminal' in r['reason']
assert sum(r.get('execution',{}).get('status')=='COMPLETED_NONAUTHORITATIVE' for r in call(s,command='status')['tasks'])==1
checks.append('P1_one_persisted_completion_for_binding')
s=base/'final'
f=call(s,'final_save_fails',expected=1); assert f['status']=='FINALIZE_FAILED' and f['task_id'] and f['execution']['status']=='COMPLETED_NONAUTHORITATIVE'
assert json.loads((s/f['task_id']/'receipt.json').read_text())['status']=='RUNNING'
assert call(s,command='status')['tasks'][0]['status']=='INTERRUPTED_REQUIRES_DECISION'; checks.append('P2_postexecution_save_failure_exit1_and_task_id')
s=base/'special'; fifo=base/'fifo'; os.mkfifo(fifo)
symlink=base/'link'; symlink.symlink_to(work/'example_stock.json')
linkdir=base/'linkdir'; linkdir.symlink_to(work,target_is_directory=True)
big=base/'big'; big.write_bytes(b' '*1048577)
for name,path in [('fifo',fifo),('device',Path('/dev/zero')),('symlink',symlink),('ancestor_symlink',linkdir/'example_stock.json'),('oversize',big)]:
 for kind in ('input','archive'):
  start=time.monotonic()
  call(s,command='plan',inp=path if kind=='input' else None,arc=path if kind=='archive' else None,expected=2)
  assert time.monotonic()-start<5
  assert call(s,command='status')=={'tasks':[]}
  checks.append('P5_'+kind+'_'+name+'_bounded_refusal')
plan=call(base/'pin',command='plan'); ih=plan['binding']['input_sha256']
call(base/'pin',command='plan',extra=['--expect-input-sha256',ih])
r=call(base/'pin',extra=['--expect-input-sha256','0'*64],expected=2); assert r['reason']=='input_hash_mismatch'
assert call(base/'pin',command='status')=={'tasks':[]}; checks.append('plan_input_pin_enforced_before_task_creation')
# Force a growing stream behind a regular-file descriptor with an initially small stat size.
spec=importlib.util.spec_from_file_location('subject',runner); subject=importlib.util.module_from_spec(spec); spec.loader.exec_module(subject)
original_read=subject.os.read; total=[0]
def endless(fd,n):
 total[0]+=n
 return b'x'*n
subject.os.read=endless
try:
 try: subject.read_regular(work/'example_stock.json',1024)
 except ValueError as exc: assert str(exc)=='file_too_large'
 else: raise AssertionError('unbounded stream accepted')
finally: subject.os.read=original_read
assert total[0]==1025; checks.append('descriptor_read_hard_cap_limit_plus_one')
assert c['runner_sha256']==hashlib.sha256(runner.read_bytes()).hexdigest() and c['python_version']; checks.append('receipt_runner_and_python_provenance')
report={'status':'PASS','checks':checks,'count':len(checks),'root':str(base),'scope':'Builder-run tests with unchanged reviewer fault injector. Process death and injected disk-full are tested, not hardware power loss. No exactly-once external side effect claim.'}
report_path.write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))
