"""Bounded stock task adapter for the frozen R0.2 runtime. Linux/root only."""
import argparse
import dataclasses
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import uuid
import zipfile

PARENT = '51d1c276caac42b185eee22927c6cee2376bdd16a1b70df18e1b7bb6503f1aab'
WORKER = '''def main(inp):
    rows=[]
    matched=[]
    for item in sorted(set(inp['expected']) | set(inp['counted'])):
        expected=inp['expected'].get(item)
        counted=inp['counted'].get(item)
        if expected == counted:
            matched.append(item)
        else:
            rows.append({'item':item,'expected':expected,'counted':counted,
                         'difference':None if expected is None or counted is None else counted-expected})
    return {'discrepancies':rows,'matched':matched}
'''

def digest(data):
    return hashlib.sha256(data).hexdigest()

def decode(data):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate_json_key')
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=pairs)

def validate(data):
    obj = decode(data)
    if not isinstance(obj, dict) or set(obj) != {'expected', 'counted'}:
        raise ValueError('expected_and_counted_maps_required')
    for values in obj.values():
        if not isinstance(values, dict) or len(values) > 1000:
            raise ValueError('invalid_stock_map')
        for key, value in values.items():
            if not isinstance(key, str) or not key.strip() or len(key) > 120 or any(ord(c) < 32 for c in key):
                raise ValueError('invalid_item_name')
            if type(value) is not int or not 0 <= value <= 10**9:
                raise ValueError('quantity_must_be_nonnegative_integer')
    return obj

def private_root(path):
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise PermissionError('linux_root_required')
    path = Path(os.path.abspath(path))
    current = Path('/')
    for part in path.parts[1:]:
        current /= part
        try:
            st = current.lstat()
        except FileNotFoundError:
            current.mkdir(mode=0o700)
            st = current.lstat()
        if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or st.st_mode & 0o022:
            raise PermissionError('unsafe_state_path')
    if path.stat().st_mode & 0o077:
        raise PermissionError('state_root_must_be_private')
    return path

def read_regular(path, limit):
    """Capture bounded regular-file bytes without following any symlink component.

    Paths may be outside the protected state root. Their contents are untrusted.
    An optional expected hash supplies continuity from a prior plan.
    """
    path = Path(os.path.abspath(path))
    parent = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    fd = None
    try:
        for part in path.parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            parent = child
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError('regular_file_required')
        if before.st_size > limit:
            raise ValueError('file_too_large')
        chunks = []
        remaining = limit + 1
        while remaining:
            chunk = os.read(fd, min(65536, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b''.join(chunks)
        if len(data) > limit:
            raise ValueError('file_too_large')
        after = os.fstat(fd)
        if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise ValueError('file_changed_during_read')
        return data
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)

def save(path, obj):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('x', encoding='utf8') as stream:
        json.dump(obj, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def run(args):
    import fcntl
    os.umask(0o077)
    sys.dont_write_bytecode = True
    root = private_root(args.state)
    if args.command != 'status':
        data = read_regular(args.input, 1024*1024)
        payload = validate(data)
        if args.expect_input_sha256 and digest(data) != args.expect_input_sha256.lower():
            raise PermissionError('input_hash_mismatch')
        raw = read_regular(args.archive, 512241)
        if len(raw) != 512241 or digest(raw) != PARENT:
            raise PermissionError('candidate_hash_mismatch')
    with (root/'runner.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('runner_busy')
        records = sorted(root.glob('*/receipt.json'))
        if args.command == 'status':
            states = []
            for path in records:
                record = decode(path.read_bytes())
                if record['status'] in ('PREPARED', 'RUNNING'):
                    record['status'] = 'INTERRUPTED_REQUIRES_DECISION'
                    save(path, record)
                states.append(record)
            return {'tasks': states}
        binding = {'task': 'stock-reconcile', 'input_sha256': digest(data),
                   'worker_sha256': digest(WORKER.encode()), 'candidate_sha256': PARENT,
                   'capability': 'process.isolated.execute.v1'}
        if args.command == 'plan':
            return {'status':'READY', 'binding':binding, 'items':len(set(payload['expected']) | set(payload['counted'])), 'effect':'Read supplied stock values and return discrepancies; no authority admission.'}
        prior = None
        if args.retry:
            if not re.fullmatch('[0-9a-f]{32}', args.retry):
                raise ValueError('invalid_retry_id')
            all_records = [decode(path.read_bytes()) for path in records]
            if any(r['binding'] == binding and (r['status'] == 'COMPLETED' or r.get('execution', {}).get('status') == 'COMPLETED_NONAUTHORITATIVE') for r in all_records):
                raise ValueError('retry_not_allowed_for_terminal_task')
            if any(r.get('retry_of') == args.retry for r in all_records):
                raise ValueError('retry_already_has_child_use_status')
            prior = decode((root/args.retry/'receipt.json').read_bytes())
            if prior['binding'] != binding:
                raise ValueError('retry_binding_mismatch')
            if prior['status'] in ('COMPLETED', 'RETRIED'):
                raise ValueError('retry_not_allowed_for_terminal_task')
        else:
            for path in records:
                old = decode(path.read_bytes())
                if old['binding'] == binding:
                    raise ValueError('task_already_recorded_use_status_or_explicit_retry')
        runner_hash = digest(Path(__file__).read_bytes())
        task_id = uuid.uuid4().hex
        taskdir = root/task_id
        taskdir.mkdir(mode=0o700)
        receipt = {'task_id':task_id, 'status':'PREPARED', 'binding':binding,
                   'runner_sha256':runner_hash, 'python_version':sys.version,
                   'retry_of':args.retry, 'authority':'NONAUTHORITATIVE_MODULE_OUTPUT'}
        try:
            save(taskdir/'receipt.json', receipt)
            if prior:
                prior['status'] = 'RETRIED'
                prior['retry_child'] = task_id
                save(root/args.retry/'receipt.json', prior)
            try:
                (taskdir/'input.json').write_bytes(data)
                tree = taskdir/'candidate'
                tree.mkdir()
                with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                    names = archive.namelist()
                    if len(names) != len(set(names)):
                        raise ValueError('duplicate_archive_member')
                    for name in names:
                        target = tree/name
                        if not target.resolve().is_relative_to(tree.resolve()):
                            raise ValueError('unsafe_archive_member')
                        if name.endswith('/'):
                            target.mkdir(parents=True, exist_ok=True)
                        else:
                            target.parent.mkdir(parents=True, exist_ok=True)
                            target.write_bytes(archive.read(name))
                sys.path.insert(0, str(tree/'SOURCE'))
                from levis_composed.runtime import LevisCompositionRuntime
                runtime = LevisCompositionRuntime(taskdir/'runtime')
                try:
                    lease = runtime.supervisor.register_module_instance(
                        module_instance_id=task_id, module_implementation_id='stock-reconcile.v1',
                        room_id='task-runner', slot_id='stock',
                        capability_ids=frozenset({binding['capability']}), grant_id='default.module_abi.v1')
                    receipt.update(status='RUNNING', lease_id=lease.lease_id)
                    save(taskdir/'receipt.json', receipt)
                    result = runtime.run_isolated_module_source(
                        module_instance_id=task_id, room_id='task-runner', slot_id='stock',
                        lease_id=lease.lease_id, source_text=WORKER, input_object=payload)
                    receipt['execution'] = dataclasses.asdict(result)
                    receipt['status'] = 'COMPLETED' if result.status == 'COMPLETED_NONAUTHORITATIVE' else 'FAILED'
                finally:
                    runtime.close()
            except Exception as exc:
                receipt.update(status='FAILED', error=str(exc), error_type=type(exc).__name__)
            save(taskdir/'receipt.json', receipt)
            return receipt
        except Exception as exc:
            return {**receipt, 'status':'FINALIZE_FAILED' if 'execution' in receipt else 'TASK_RECORD_FAILED',
                    'task_id':task_id, 'error':str(exc), 'error_type':type(exc).__name__,
                    'recovery':'Use status to inspect persisted state; execution may have occurred. No automatic retry.'}

def main():
    parser = argparse.ArgumentParser(description='LEVIS stock task runner (Linux root)')
    parser.add_argument('--state', required=True, help='Root-private Linux state directory')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    for command in ('plan', 'run'):
        task = sub.add_parser(command, help='Inspect or run the fixed stock-reconcile task')
        task.add_argument('--archive', required=True)
        task.add_argument('--input', required=True)
        task.add_argument('--expect-input-sha256', help='Require the exact input hash shown by plan')
        task.add_argument('--retry', help='Explicitly retry a failed/interrupted task ID with identical bindings')
    args = parser.parse_args()
    try:
        result = run(args)
        print(json.dumps(result, indent=2))
        return 1 if result.get('status') in ('FAILED', 'FINALIZE_FAILED', 'TASK_RECORD_FAILED') else 0
    except Exception as exc:
        print(json.dumps({'status':'REFUSED','reason':str(exc),'type':type(exc).__name__}))
        return 2

if __name__ == '__main__':
    sys.exit(main())
