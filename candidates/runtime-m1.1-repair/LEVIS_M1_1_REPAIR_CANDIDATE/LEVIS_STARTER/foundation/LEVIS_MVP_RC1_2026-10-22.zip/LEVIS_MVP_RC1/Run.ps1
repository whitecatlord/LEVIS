param(
    [ValidateSet('verify','plan','run','status')][string]$Command = 'verify',
    [string]$InputFile,
    [string]$ExpectedHash,
    [string]$Retry,
    [string]$InstallDirectory = '/root/levis-mvp-rc1',
    [string]$State = '/root/levis-mvp-state'
)
$ErrorActionPreference = 'Stop'
$cliArgs = @('-u','root','--','python3',"$InstallDirectory/levis.py",$Command,'--state',$State)
if ($Command -in @('plan','run')) {
    if (!$InputFile) { throw 'Provide -InputFile with your stock JSON path.' }
    $resolvedInput = (Resolve-Path -LiteralPath $InputFile).Path
    $linuxInput = & wsl -u root -- wslpath -a ($resolvedInput.Replace('\','/'))
    if ($LASTEXITCODE -ne 0) { throw 'Cannot translate input path.' }
    $linuxInput = $linuxInput.Trim()
    $cliArgs += @('--input',$linuxInput)
    if ($ExpectedHash) { $cliArgs += @('--expect-input-sha256',$ExpectedHash) }
    if ($Retry) { $cliArgs += @('--retry',$Retry) }
}
& wsl @cliArgs
exit $LASTEXITCODE
