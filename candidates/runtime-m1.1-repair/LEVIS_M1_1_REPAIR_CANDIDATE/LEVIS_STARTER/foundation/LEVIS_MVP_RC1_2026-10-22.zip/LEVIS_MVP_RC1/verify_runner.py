import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
os.umask(0o077)
script=Path(sys.argv[1]); archive=Path(sys.argv[2]); output=Path(sys.argv[3])
base=Path(tempfile.mkdtemp(prefix='levis_runner_check_',dir='/root')); state=base/'state'
inputfile=base/'input.json'; inputfile.write_text(json.dumps({'expected':{'a':4,'b':3},'counted':{'a':4,'b':1,'c':8}}))
hash_before=hashlib.sha256(archive.read_bytes()).hexdigest()
cases=[]
def call(command='run', inp=inputfile, arc=archive, extra=(), code=0, reason=None):
 cmd=[sys.executable,str(script),'--state',str(state),command]
 if command!='status': cmd+=['--archive',str(arc),'--input',str(inp),*extra]
 p=subprocess.run(cmd,capture_output=True,text=True)
 assert p.returncode==code,(cmd,p.stdout,p.stderr)
 result=json.loads(p.stdout)
 if reason: assert reason in result.get('reason',''),result
 return result
plan=call('plan'); assert plan['status']=='READY' and not list(state.glob('*/receipt.json')); cases.append('plan_without_execution')
r=call(); assert r['status']=='COMPLETED'; assert r['execution']['output']=={'matched':['a'],'discrepancies':[{'item':'b','expected':3,'counted':1,'difference':-2},{'item':'c','expected':None,'counted':8,'difference':None}]}; cases.append('real_runtime_correct_generic_output')
call(code=2,reason='already_recorded'); cases.append('duplicate_refused')
call(extra=['--retry',r['task_id']],code=2,reason='terminal'); cases.append('completed_retry_refused')
bad=base/'bad.zip'; bad.write_bytes(b'wrong'); call(arc=bad,code=2,reason='hash_mismatch'); cases.append('wrong_parent_refused')
for text in ['{"expected":{"a":true},"counted":{}}','{"expected":{"a":-1},"counted":{}}','{"expected":{},"expected":{},"counted":{}}','{"expected":{"a":1.5},"counted":{}}']:
 invalid=base/'invalid.json'; invalid.write_text(text); call(inp=invalid,code=2)
cases.append('invalid_and_duplicate_key_inputs_refused')
# Simulate a persisted RUNNING journal after a crashed process. No live execution exists.
receipt=state/r['task_id']/'receipt.json'; original=receipt.read_bytes(); rec=json.loads(original); rec['status']='RUNNING'; rec.pop('execution',None); receipt.write_text(json.dumps(rec))
status=call('status'); assert status['tasks'][0]['status']=='INTERRUPTED_REQUIRES_DECISION'; cases.append('interruption_requires_decision')
changed=base/'changed.json'; changed.write_text('{"expected":{},"counted":{}}'); call(inp=changed,extra=['--retry',r['task_id']],code=2,reason='binding_mismatch'); cases.append('retry_changed_input_refused')
retry=call(extra=['--retry',r['task_id']]); assert retry['status']=='COMPLETED' and retry['retry_of']==r['task_id']; cases.append('explicit_retry_new_receipt')
import fcntl
with (state/'runner.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX); call('status',code=2,reason='runner_busy')
cases.append('concurrent_runner_refused')
unsafe=base/'unsafe'; unsafe.mkdir(); unsafe.chmod(0o777)
p=subprocess.run([sys.executable,str(script),'--state',str(unsafe),'status'],capture_output=True,text=True); assert p.returncode==2 and 'unsafe_state_path' in p.stdout; cases.append('unsafe_state_refused')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==hash_before
report={'status':'PASS','checks':cases,'candidate_unchanged':True,'candidate_sha256':hash_before,'first_receipt':r,'retry_receipt':retry,'test_root':str(base),'qualification':'Interrupted state simulated in journal; not a power-loss test. Builder-run verification, not independent review.'}
output.write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps({'status':'PASS','checks':cases,'test_root':str(base)}))
