# LEVIS MVP RC1

This local development release candidate provides an end-to-end stock reconciliation task: validate input, plan with an input hash, obtain a Supervisor lease, execute the fixed worker through the Base isolation mechanism, and retain a result and lifecycle receipt. It is not a general conversational AI, autonomous agent, or complete implementation of the longer-range LEVIS design.

## Windows with WSL

Requirements: WSL Ubuntu, Python 3, and permission to run WSL as root. The tested environment is recorded in `evidence/`. Extract this complete folder, open PowerShell here, then:

```powershell
.\Install.ps1
.\Run.ps1 -Command verify
.\Run.ps1 -Command plan -InputFile .\example_stock.json
.\Run.ps1 -Command run -InputFile .\example_stock.json -ExpectedHash HASH_FROM_PLAN
.\Run.ps1 -Command status
```

Replace `HASH_FROM_PLAN` with `binding.input_sha256` in the plan output. Installation refuses to overwrite `/root/levis-mvp-rc1`; choose a fresh `-Destination /root/levis-your-name` and pass the same directory as `-InstallDirectory` to Run.ps1. If local PowerShell policy blocks scripts, use the Linux commands below rather than changing machine policy.

Input example:

```json
{"expected":{"bolts":12,"washers":5},"counted":{"bolts":10,"washers":5,"nuts":3}}
```

Missing items differ from zero; quantities must be nonnegative integers. Output contains discrepancies and matching item names as escaped JSON. An input is data, never an authorization token. Plan does not authorize Run. Preserve the full result and task ID when troubleshooting.

## Linux

Copy the complete package to a new protected directory below `/root`, with root ownership and no group/other write permissions in any ancestor. State must also be root-private. Do not execute from `/mnt/c` or `/tmp`.

```sh
cd /root/levis-mvp-rc1
python3 levis.py verify
python3 levis.py plan --input example_stock.json
python3 levis.py run --input example_stock.json --expect-input-sha256 HASH_FROM_PLAN
python3 levis.py status
```

The default durable task history is `/root/levis-mvp-state`. A different `--state` (or PowerShell `-State`) creates a separate history; it does not share duplicate/retry protection. Inspect `status` before retrying. For a failed or interrupted leaf task, an explicit retry is `python3 levis.py run --input SAME_INPUT --expect-input-sha256 SAME_HASH --retry TASK_ID`. Existing retry children and persisted successful executions block retries. There is no automatic retry or cleanup. Back up the entire state directory while no command is running; do not edit receipts to force another execution.

Exit codes: 0 completed command; 2 validation/refusal; 1 execution or receipt finalization failure. Results remain nonauthoritative.

## Provenance and governance

Base archive: R0.2 SHA-256 `51d1c276caac42b185eee22927c6cee2376bdd16a1b70df18e1b7bb6503f1aab`. Runner: adopted R1.1 SHA-256 `6fb64647ed7da767774b58b8b1ca0cc9e34813ba6c618277facf8c66a07145ce`. Both are byte-identical to the audited originals. The complete adopted packet and original runner archive are preserved. Its historical candidate labels remain intact; subsequent acceptance/adoption records supply their later bounded status.

New integration files were authored by Codex on 2026-10-22. They supply installation, hash checking, and command routing. They do not change Base admission, truth selection, promotion, ownership, leases, or runner retry policy. The new packaging/launcher has builder verification only and awaits separate review. No new Operator seal, runtime authority, independent safety certification, or public release approval is asserted.

The Base archive contains the architecture ownership contract, applicability map, lineage ledger, historical HOLDs, and residuals. Preserve these. Fifteen of sixteen lineage archives were historically verified; RC2e.2 remains a reconstructed manifest without the original archive. The host lineage is record-attested. The outer RC2b assurance launcher is not inherited; class-wide verify/reread closure is not established. Lab VIEW, reconstruction, ESI, agency, legitimacy, and visualization capabilities have not been integrated or promoted by this package.

## Limits and verification

- Only the fixed pure-computation stock worker is supported. No arbitrary code, network service, side-effecting worker, model connection, or clinical application is supplied.
- A crash after execution but before durable finalization can cause recomputation on explicit retry. Exactly-once execution and hardware power-loss durability are unproven.
- Cleanup failure can label a completed execution FAILED; inspect the preserved execution before deciding what to do.
- Opening special files can have device effects before the inherited regular-file check. Only supply ordinary Operator-controlled input files. Network/FUSE reads can stall.
- Root/same-account code, Linux kernel, Python/dependencies, bootstrap files, and initial source path remain trusted. SHA-256 manifests detect accidental byte changes relative to a trusted manifest; they are unsigned and are not authentication against an attacker replacing the package and manifest together.
- Windows is a convenience entry point into WSL. Native Windows execution does not satisfy the Base boundary. No security equivalence between WSL and a separate hardened host is claimed.

See `evidence/` for actual results and logs. Tests establish the checked behavior in the recorded environment, not general safety. To rerun inherited controls, extract `inherited_verification.zip` directly inside a fresh protected Linux directory and follow its original README. Do not extract that nested archive on Windows: it contains case-distinct `REVIEW_INPUT` and `review_input` directories. Base tests additionally require pytest; normal execution uses Python's standard library. The repair verifier uses `/root/rv/pre/tree`, refuses differing existing bytes, and creates fresh private test directories. Do not run the inherited reviewer shell deletion probe against valuable directories.
