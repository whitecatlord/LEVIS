# R1.1 adoption — 2026-10-15

Operator statement: "Adopt it". Recorded from this Codex conversation in response to the bounded stock-worker acceptance question. Exact message time unavailable; this is an unsigned conversation record.

**Adopted: fixed pure-computation stock worker only.**

Target package SHA-256: `73e8fce72d7d56ebbfc8628856a11e577b35a576d39a3d60646dab55667aac25` (2601477 bytes).
Runner SHA-256: `6fb64647ed7da767774b58b8b1ca0cc9e34813ba6c618277facf8c66a07145ce`.
Returned review ZIP SHA-256: `3a16f2b1d7306a2dc47345aa9c6e6f83c3afcbd32241036d2dcfeacfe9c0b7ce`.
Review Markdown SHA-256: `8545ef594ee6a3c62f4f1bbe38bff01382fa5c33d70988a4d871ee5099625562`.
Adoption JSON SHA-256: `26285b5c903661031d7a041943b67ec0561c80f4959d048e00f46dbed59c6a51`.

- Only the fixed pure-computation stock worker is adopted. Side-effecting workers require a separate idempotency/unknown-outcome recovery design and review.
- A crash after execution but before durable completion can cause explicit retry to recompute. Exactly-once execution and hardware power-loss durability are not established.
- Any persisted success blocks further retries of the same binding in the same state root. This policy is adopted for this scope; separate state roots have separate histories.
- Cleanup errors after successful execution may be labelled FAILED while retaining the result and refusing retries.
- File type is checked after opening the path; devices may react to open. Special-file refusal is before reading contents, not before opening.
- Pre-receipt crashes can leave orphan directories; no automatic retention tooling.
- Claude review is separate from Codex implementation but anchored to fixes Claude proposed. Codex assesses the retry policy as suitable for pure computation; this is not a cold policy review.
- Existing Linux/root, protected-state, trusted bootstrap/root/same-account and R0.2 review/lineage limits remain. No runtime authority, public release or cryptographic signature is granted.

Original candidate, build records and review are preserved unchanged. This adoption is separate from their historical statuses. Changed bytes or scope require renewed review/adoption.
