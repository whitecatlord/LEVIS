param([string]$Destination = '/root/levis-mvp-rc1')
$ErrorActionPreference = 'Stop'
$sourcePath = & wsl -u root -- wslpath -a ($PSScriptRoot.Replace('\','/'))
if ($LASTEXITCODE -ne 0) { throw 'WSL Ubuntu with Python 3 is required.' }
$sourcePath = $sourcePath.Trim()
$installCode = @'
import os, pathlib, shutil, subprocess, sys
source = pathlib.Path(sys.argv[1])
target = pathlib.Path(sys.argv[2])
if target.parent != pathlib.Path('/root') or not target.name.startswith('levis-'):
    raise SystemExit('Destination must be a new /root/levis-* directory')
if target.exists() or target.is_symlink():
    raise SystemExit('Destination already exists; choose a new destination')
subprocess.run([sys.executable, str(source/'levis.py'), 'verify'], check=True)
os.umask(0o077)
shutil.copytree(source, target, symlinks=False)
for path in target.rglob('*'):
    path.chmod(0o700 if path.is_dir() else 0o600)
target.chmod(0o700)
subprocess.run([sys.executable, str(target/'levis.py'), 'verify'], check=True)
print('Installed: ' + str(target))
'@
& wsl -u root -- python3 -c $installCode $sourcePath $Destination
if ($LASTEXITCODE -ne 0) { throw 'Installation failed; inspect the message above.' }
